from django.shortcuts import render,redirect
from pytube import YouTube
# Create your views here.
def index(request):
    if request.method=='POST':
        link=request.POST.get('url')
        directory=request.POST.get('path')
        print(link,directory)
        video = YouTube(link)
        stream = video.streams.get_highest_resolution()
        strip_directory = directory.strip('"')
        try:
            stream.download(strip_directory)
            msg="Downloaded"
        except:
            msg="Failed"
        return render(request,'index.html',{'message':msg})
    else:
        return render(request,"index.html")